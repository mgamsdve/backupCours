﻿namespace _5TTI_MaelDP_NombreDeMots
{
    internal class Program
    {

        static void Main(string[] args)
        {
            //Déclaration
            string recommencer; //Variable pour recommencer
            string phrase;   //La phrase de l’utilisateur
            int nombreDeMot; //Le nombre de mot dans la phrase



            //Boucle recommencer
            do
            {
                Console.Clear();
                Console.WriteLine("Bienvenue dans le programme pour compter les mots");

                //Lecture
                Console.WriteLine("Ecriver votre phrase : ");
                phrase = Console.ReadLine();

                //Traitement
                NombreMot(phrase, out nombreDeMot);

                //Affichage du résultat
                Console.WriteLine("Il y a " + nombreDeMot + " mots dans votre phrase.");

                Console.WriteLine("Entrez espace pour recommencer");
                recommencer = Console.ReadLine();
            }
            while (recommencer == " ");
    
        }

        static void NombreMot(string phrase, out int nombreDeMot)
        {
            int phraseLen;   //nombre de caractere de la phrase
            int x;           //parcour chaque caractere de la phrase

            phraseLen = phrase.Length; 
            nombreDeMot = 1;

            for (x = 0; x < phraseLen; x++) //Parcourir chaque caractere un par un de la phrase
            {
                if (phrase[x] == ' ')
                {
                    nombreDeMot++;
                }
            }
        }
    }
}
